quantel.mib is the top level quantel mib (the others refer to it)
cacheserver.mib is the old linux browsecache
isaManager.mib is for type 2 only (no type 3 yet)
clipnet.mib is good for type2/3
clipnet2.mib is for the new clipnet card (don't ask)
quentinM.mib is for molly type 2
quentinMv3.mib is for molly type 3
quentinR.mib is for rocky type 2
quentinRv3.mib is for rocky type 3
sQCache.mib is good for type2/3